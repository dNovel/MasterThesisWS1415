1. Copy all zip files in this folder to:
	C:\Users\[user name]\My Documents\Visual Studio [Version]\Templates\ProjectTemplates\Visual C#\FUSEE\
2. Open Visual Studio and load the FUSEE engine.
3. You can now use the template to add a new project via the "Add -> New Project" dialog (category "FUSEE").
4. Important: Set project path to "[...]\dev\src\Engine\Examples\"