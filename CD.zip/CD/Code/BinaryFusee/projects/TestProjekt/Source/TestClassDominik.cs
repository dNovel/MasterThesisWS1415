using Fusee.Engine;
using Fusee.Math;

namespace TestProjekt.TestClassDominik
{

    public class TestClassDominik
    {

        public TestClassDominik()
        {
			
        }

    }

}