1. Copy all zip files in this folder to:
	C:\Users\[user name]\My Documents\Visual Studio [Version]\Templates\ItemTemplates\Visual C#\FUSEE\
2. Open Visual Studio and load the FUSEE engine.
3. You can now use the template to add a new config file via the "Add -> New Item" dialog (category "FUSEE").